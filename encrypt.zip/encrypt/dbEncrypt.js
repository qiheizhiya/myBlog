module.exports = {
    localDbInfo: {
        dbName: 'blog',
        userName: 'root',
        password: '123321sss',
        host: {
            host: 'localhost',
            dialect: 'mysql'
        }
    },
    aliDbInfo: {
        dbName: 'blog',
        userName: 'root',
        password: '@@@Abc123321sss',
        host: {
            host: '120.78.196.23',
            dialect: 'mysql'
        }
    }
}