module.exports = {
    region: 'oss-cn-shenzhen',
    accessKeyId: 'LTAI4GDzcetJ7bnf2fafPUVg',
    accessKeySecret: 'DfDNr6PzyeEB8fy9k95wqw6f5Y5sjq',
    bucket: 'qiheizhiya',
}